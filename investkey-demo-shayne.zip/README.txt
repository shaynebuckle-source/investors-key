InvestKey Newfoundland — Shayne’s Simple Live Demo

WHAT THIS IS
- A one-page site that lists a few sample properties.
- The “Email to Book” button opens your email app to send to shaynebuckle@royallepage.ca.
- No backend, no keys — goes live in under a minute.

HOW TO PUT IT ONLINE (3 clicks)
1) Go to https://app.netlify.com/drop
2) Drag this index.html file into the page.
3) Netlify gives you a live link. Share it!

OPTIONAL (Vercel):
- Go to https://vercel.com → New Project → “Other” → upload index.html.

WHEN YOU’RE READY FOR REAL LISTINGS & FORMS
- We’ll switch to the full frontend + backend build you already have links for.
